<?php
session_start();
include "connect.php";
include "BarcodeQR.php"; 
// escape variables for security
$name = $_GET["nama"];
$ttl = $_GET["ttl"];
$nohp = $_GET["nohp"];
$keluhan = $_GET["keluhan"];
$kode_rumahsakit=$_SESSION["rs"];
$slot=$_GET["slot"];
$uniqueid=uniqid(substr($nohp,5));
// set BarcodeQR object 
$qr = new BarcodeQR(); 
// create URL QR code 
$qr->url($uniqueid); 
$sql="INSERT INTO `pesanan`(`nama`,`nohp`, `rumahsakit`, `keluhan`, `status`, `tanggal_pesanan`, `kode_pesanan`, `ttl`)
VALUES ('$name','$nohp','$kode_rumahsakit', '$keluhan', 'pending', NOW(),'$uniqueid', '$ttl' )";
$query="UPDATE waktu SET status='terpesan' where id='".$slot."'";
	mysqli_query($conn, $query);
if (!mysqli_query($conn,$sql)) {
  die('Error: ' . mysqli_error($conn));
}

echo '<div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Hasil Registrasi</h4>
      </div>
      <div class="modal-body">
      <div class="form-group">
  <label >Nama :</label>'.$name.'
</div>
  <div class="form-group">
  <label >Tanggal Lahir :</label>'.$ttl.'
</div>
      <div class="form-group">
    <label >No Hp :</label>'.$nohp.'
</div>
     <div class="form-group">
    <label for="comment">Keluhan :</label>'.$keluhan.'
</div>';
$qr->draw(150, "../images/qr-code.png");
echo '<div class="form-group">
  <label >QR-Code :</label><img alt="qrcode" src="source/images/qr-code.png"/>
</div>';
echo '</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        <button type="button" class="btn btn-default btn-success " onclick="javascript:window.print();">Cetak</button>
      </div>
    </div>';

mysqli_close($conn);
?>