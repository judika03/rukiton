<?php
session_start();
include "connect.php";
echo '
      <script src="source/js/jquery-1.11.3.min.js"></script>';
echo '
<script>
var slot;
function changeslot(str){
	slot=str;
}
function loadRegist(){
	$.get("source/html/registrasi.html?",function(data){
	$("#regist").html(data);
});
}
</script>
';
$klinik=$_GET["k"];
	$query="select id, status, waktu from waktu where kode_klinik='".$klinik."'";
$result = mysqli_query($conn, $query);
	echo "<h3>Pilihan Slot : </h3><hr>";
	echo '<table class="table table-striped"><thead><tr>';
    while($row = mysqli_fetch_assoc($result)){
		if($row["status"]=="kosong"){
		echo '<a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal" onclick="loadRegist(); changeslot(\''.$row["id"].'\');">'.$row["waktu"].'</a>';
		} if ($row["status"]=="terpesan"){
		echo '<a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal" onclick="loadRegist(); changeslot(\''.$row["id"].'\');" disabled>'.$row["waktu"].'</a>';
		}
	}
	echo '<script>
	
	function sendData(nama,ttl,nohp,keluhan){
$.get("source/php/registration.php?nama="+nama+"&ttl="+ttl+"&nohp="+nohp+"&keluhan="+keluhan+"&slot="+slot,function(data){
	$("#regist").html(data);
});
 return false;
}
</script>
';
//nanti dipisah
echo "<style>.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px; /* Adjusts for spacing */
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}</style>";
    echo '</tr></thead></table>';
echo '
    	<form id="formid" >
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog" id="regist">

    
  </div>
</div>
</form>
';
mysqli_close($conn);
?>