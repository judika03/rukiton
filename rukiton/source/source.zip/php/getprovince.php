<?php
include "connect.php";

$sql = "SELECT nama FROM provinsi";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
	echo('<option value="#">Pilih Provinsi</option>');
    while($row = mysqli_fetch_assoc($result)) {
        echo (' <option value="'.$row["nama"].'">'.$row["nama"].'</option>');
    }
} else {
    echo "0";
}

mysqli_close($conn);
?>