<?php
include "connect.php";
$lokasi=$_GET["l"];
$sql = "SELECT  nama FROM rumahsakit where lokasi='".$lokasi."'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
	echo('<h3>List Rumah Sakit</h3> <hr>');
	echo '<div class="list-group">';
		echo '<div style="height:400px;border:0px solid #ccc;font:16px/26px Georgia, Garamond, Serif;overflow:auto;">';
    while($row = mysqli_fetch_assoc($result)) {
        echo ('<a class="list-group-item" href="getpage.php?n='.$row['nama'].'" ><span class="glyphicon glyphicon-plus"></span> '.$row['nama'].'</a>');
    }
	echo '</div>';
	echo '</div>';
} else {
    echo "0";
}

mysqli_close($conn);
?>
