
   <?php
include "header.php";
include "source/php/Barcode39.php";
$query="select latitude, longitude from province";
$result=mysqli_query($conn, $query);
$row
   ?>
   
	
<script>
var lokasi =new google.maps.LatLng(latitude,longitude);
var marker=new google.maps.Marker({
  position:lokasi,
  icon:'source/images/hospital_logo.png',
  animation:google.maps.Animation.BOUNCE
  });
  function changemap(str1,str2,Zoom){
			latitude=str1;
			longitude=str2;
			zooms=Zoom;
			Gmap();
			<?php
 $query="select latitude,longitude from rumahsakit";
 $result=mysqli_query($conn, $query);
 while($row=mysqli_fetch_array($result)){
 echo 'lokasi=new google.maps.LatLng('.$row["latitude"].','.$row["longitude"].'); ';
 echo 'marker=new google.maps.Marker({
  position:lokasi,
  icon:"source/images/hospital_logo.png",
  });';
 echo 'marker.setMap(map);';
 }
 ?>
		}
function initialize() {
	
	loadProvince();

  var mapProp = {
    center:new google.maps.LatLng(latitude,longitude),
    zoom:15,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
 <?php
 $query="select latitude,longitude from rumahsakit";
 $result=mysqli_query($conn, $query);
 while($row=mysqli_fetch_array($result)){
 echo 'lokasi=new google.maps.LatLng('.$row["latitude"].','.$row["longitude"].'); ';
 echo 'marker=new google.maps.Marker({
  position:lokasi,
  icon:"source/images/hospital_logo.png",
  });';
 echo 'marker.setMap(map);';
 }
 ?>

}
google.maps.event.addDomListener(window, 'load', initialize);
</script>
   </head>
   <body class="background" >
   <div id="indexID">
   <div class="container">
   <div class="col-md-7">
   <div class="jumbotron" id="googleMap" style="height:500px;" ></div>
   </div>
                
                
						

                   
                
	<div class="col-md-4" id="panelID" >
	 
	 	

   </div>
   </body>
   </div>
   </div>
      <div id="modalID" class="modal fade" role="dialog" >
  <div class="modal-dialog">



  </div>
</div>
    	<form id="formid" >
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog" id="regist">

    
  </div>
</div>
</form>
<?php
include "source/html/footer.html";
?>