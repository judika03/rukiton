<?php
$nama=$_GET["n"];
   include "connect.php";
   echo '<script src="source/js/rukiton.js" ></script>';
if(!empty($nama)){


$sql = "SELECT nama, alamat, foto, profil, kode_rumahsakit FROM rumahsakit where nama='".$nama."'";
$result = mysqli_query($conn, $sql);
echo "<div class='container' >";
if (mysqli_num_rows($result) > 0) {
    // output data of each row
  $row = mysqli_fetch_assoc($result);
  $_SESSION["rs"] = $row["kode_rumahsakit"];
  $kode=$row["kode_rumahsakit"];
	echo '<div class="col-md-7">';
	echo '<div class="panel panel-default" style="padding-left:0px;">
   <div class="panel-heading">';
    echo '<h4>'.$row["nama"].'</h4>';
	echo '</div>
<div class="panel-body">';

	echo '<img class="img-responsive img-rounded" src="'.$row["foto"].'" height=300 width=600><br>';
	echo '<div class="panel-footer">';
	echo $row["profil"];
	echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
	echo '<div class="col-md-5" id="content">';
	echo '<div class="panel panel-default">
   <div class="panel-heading">';
    echo '<h4>Pilihan Klinik</h4>';
	echo '</div>';
	echo '<div style="height:400px;border:0px solid #ccc;font:16px/26px Georgia, Garamond, Serif;overflow:auto;">';
	echo '<div class="list-group">';
	$sql="select nama, kode_klinik from klinik where kode_rumahsakit='".$kode."'";
	$result = mysqli_query($conn, $sql);
	while($row = mysqli_fetch_assoc($result)){
	echo '<a href="#" onclick="loadSlot(\''.$row["kode_klinik"].'\');" class="list-group-item"><span class="glyphicon glyphicon-plus"></span> '.$row["nama"].'</a>';
	}
	echo '</div>';
	echo '</div>';
	echo '</div>';
	echo "</div>";
} else {
    echo "0";
}

mysqli_close($conn);
} else {
	$_GET["n"]="";
}
?>
   