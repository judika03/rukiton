<?php
session_start();
include "connect.php";

echo '
      <script src="source/js/jquery-1.11.3.min.js"></script>';
	  echo '
      <script src="source/js/rukiton.js"></script>';
echo '
<script>
var slot;
function changeslot(str){
	slot=str;
}
function loadRegist(str){
	$.get("source/php/registrasi.php?kode="+str,function(data){
	$("#regist").html(data);
});
}
</script>
';
$klinik=$_GET["k"];
	$query="select id, status, waktu from waktu where kode_klinik='".$klinik."'";
$result = mysqli_query($conn, $query);
	echo '<div class="col-md-7">';
	echo '<div class="panel panel-default">
   <div class="panel-heading">';
	echo "<h3>Pilihan Slot : </h3>";
	echo '</div>';
	echo '<div class="panel-body">';
	$i=0;
    while($row = mysqli_fetch_assoc($result)){
		$i+=1;
		if($row["status"]=="kosong"){
			
		echo 'Slot '.$i.': <a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal" onclick="loadRegist(\''.$klinik.'\'); changeslot(\''.$row["id"].'\');">'.$row["waktu"].'</a><br>';
		} if ($row["status"]=="terpesan"){
		echo 'Slot '.$i.': <a href="#" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal" onclick="loadRegist(\''.$klinik.'\'); changeslot(\''.$row["id"].'\');" disabled>'.$row["waktu"].'</a><br>';
		}
	}
	echo '</div>';
	echo '</div>';
	echo '<script>
	
	function sendData(nama,id,ttl,nohp,nobpjs,keluhan){
$.get("source/php/registration.php?&name="+nama+"&id="+id+"&ttl="+ttl+"&nohp="+nohp+"&nobpjs="+nobpjs+"&kl="+keluhan+"&slot="+slot+"&kk="+\''.$klinik.'\',function(data){
	$("#regist").html(data);
});
 return false;
}
</script>
';
//nanti dipisah
echo "<style>.modal {
  text-align: center;
  padding: 0!important;
}

.modal:before {
  content: '';
  display: inline-block;
  height: 100%;
  vertical-align: middle;
  margin-right: -4px; /* Adjusts for spacing */
}

.modal-dialog {
  display: inline-block;
  text-align: left;
  vertical-align: middle;
}</style>";
    echo '</tr></thead></table>';
echo '

';
mysqli_close($conn);
?>