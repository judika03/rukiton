<?php
include "connect.php";
$name=$_GET["name"];
$ttl=$_GET["ttl"];
$email=$_GET["email"];
$nohp=$_GET["nohp"];
$nobpjs=$_GET["nobpjs"];
$id=$_GET["id"];
$sql="UPDATE `user` SET `nama`='$name',`tgl_lahir`='$ttl',`email`='$ttl',`nohp`='$nohp',`nobpjs`='$nobpjs' WHERE id='".$id;."'";
mysqli_query($conn, $sql);
header('location:index.php');
?>