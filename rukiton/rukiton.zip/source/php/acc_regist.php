<?php
session_start();
include "connect.php";
$nama= mysqli_real_escape_string($conn, $_POST['name']);
$ttl=mysqli_real_escape_string($conn, $_POST['ttl']);
$email=mysqli_real_escape_string($conn, $_POST['email']);
$password=md5(mysqli_real_escape_string($conn, $_POST['password']));
$nohp=mysqli_real_escape_string($conn, $_POST['nohp']);
$nobpjs=mysqli_real_escape_string($conn, $_POST['nobpjs']);

$query="INSERT INTO `user`(`nama`, `tgl_lahir`, `email`, `password`, `nohp`, `nobpjs`, `tgl_daftar`) VALUES ('$nama','$ttl','$email','$password','$nohp','$nobpjs',NOW())";
mysqli_query($conn, $query);
$_SESSION["email"]=$email;
header('location:../../index.php');
?>