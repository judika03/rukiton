<?php
session_start();
$_SESSION["email"]="";
header('location:../../index.php');
?>