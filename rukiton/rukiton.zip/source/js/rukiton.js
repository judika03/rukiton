
var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(setPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}

function loadSlot(str,target){
	target = target?target:'#content';

$.get('source/php/getslot.php?k='+str,function(data){
	$(target).html(data);
});

}
function loadPage(str,target){
	target = target?target:'#indexID';

$.get('source/html/about.html',function(data){
	$(target).html(data);
});

}
 function SearchHospital(str,target){
	target = target?target:'#indexID';

$.get('source/php/search.php?search='+str,function(data){
	$(target).html(data);
});

}
 function loadRegistration(target){
	target = target?target:'#indexID';
$.get('source/html/regist.html',function(data){
	$(target).html(data);
});

}
function loadProvince(){
$.get("source/php/getprovince.php",function(data){
	$("#panelID").html(data);
});
}
function openHospital(str){
$.get("source/php/getpage.php?n="+str,function(data){
	$("#indexID").html(data);
});
}
function loadCity(str){
$.get("source/php/getcity.php?p="+str,function(data){
	$("#panelID").html(data);
});
}

function loadHospital(str){
$.get("source/php/gethospital.php?l="+str,function(data){
	$("#panelID").html(data);
});
}
function loadProfile(str){
$.get("source/php/getprofile.php?id="+str,function(data){
	$("#indexID").html(data);
});
}
function loadHist(str){
$.get("source/php/gethistory.php?id="+str,function(data){
	$("#indexID").html(data);
});
}
var map;
var zooms;
		var latitude, longitude;
		var bounds = new google.maps.LatLngBounds();
		latitude=-6.243181;
		longitude=106.629029;
		var lokasi =new google.maps.LatLng(latitude,longitude);
		function setPosition(position) {
			latitude = position.coords.latitude;
			longitude=position.coords.longitude;
}
var marker=new google.maps.Marker({
  position:lokasi,
  icon:'source/images/hospital_logo.png',
  animation:google.maps.Animation.BOUNCE
  });
  
		
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } 
}
function Gmap() {
	var mapProp = {
    center:new google.maps.LatLng(latitude,longitude),
    zoom:zooms,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
   map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
		}
function showPosition(position) {
  latitude=position.coords.latitude;
  longitude=position.coords.longitude;	
  changemap(latitude,longitude);
}


